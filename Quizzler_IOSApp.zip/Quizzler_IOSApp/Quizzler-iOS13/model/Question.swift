//
//  Question.swift
//  Quizzler-iOS13
//
//  Created by MacBook on 8/1/20.
//  Copyright © 2020 The App Brewery. All rights reserved.
//

import Foundation

struct Question {
    let text:String
    let answer:String
    
    init(text:String,answer:String) {
        self.text=text
        self.answer=answer
    }
}

