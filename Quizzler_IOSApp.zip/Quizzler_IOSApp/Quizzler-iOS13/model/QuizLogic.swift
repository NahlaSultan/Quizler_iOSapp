//
//  QuizLogic.swift
//  Quizzler-iOS13
//
//  Created by MacBook on 8/1/20.
//  Copyright © 2020 The App Brewery. All rights reserved.
//

import Foundation

struct QuizLogic {
    let quiz = [
           Question(text: "This is a really cool app", answer: "True"),
           Question(text: "This is just an ordinary app", answer: "False"),
           Question(text: "Babies are cute", answer: "True")
       ]
    var questionNumber = 0
    var correctCount = 0
    
    mutating func checkAnswer(answer:String) -> Bool{
         if questionNumber<3{
            if answer == quiz[questionNumber].answer{
                self.correctCount+=1
                
            }
            return answer == quiz[questionNumber].answer}
         else{
            return false
        }
        
    }
    
    mutating func incrementQuestion(){
        self.questionNumber+=1
    }
    
    func getText() -> String{
        if questionNumber<3{
            return quiz[questionNumber].text

        }
        else{
            return "Your score is \(correctCount) / \(quiz.count)"
        }
    }
    
    func getProgress() -> Float{
       return Float(questionNumber)/Float(quiz.count)

    }

}
