//
//  ViewController.swift
//  Quizzler-iOS13
//
//  Created by Angela Yu on 12/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var trueBtn: UIButton!
    @IBOutlet weak var falseBtn: UIButton!
    
    var quizBrain = QuizLogic()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        questionLabel.text = quizBrain.quiz[quizBrain.questionNumber].text

    }

    @IBAction func trueBtnPressed(_ sender: UIButton) {
        let userAnswer = sender.currentTitle
        let correctCheck = quizBrain.checkAnswer(answer: userAnswer!)
        
        if correctCheck{
            sender.backgroundColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
            
        }else{
            sender.backgroundColor = #colorLiteral(red: 0.7450980544, green: 0.1568627506, blue: 0.07450980693, alpha: 1)
        }
        
        //Timer.init(timeInterval: 0.2, target: self, selector: #selector(updateView), userInfo: nil, repeats:false)
        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(updateView), userInfo: nil, repeats: false)

    }
    
    
    
    @objc func updateView(){
        quizBrain.incrementQuestion()
        questionLabel.text = quizBrain.getText()
        progressBar.progress = quizBrain.getProgress()
        trueBtn.backgroundColor = UIColor.clear
        falseBtn.backgroundColor = UIColor.clear

    }
    
    

    
    
  
    
}

